import React, { useEffect, useState } from 'react';

function MoviesList({ onSelect }) {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    fetch('/api/movies')
      .then(res => res.json())
      .then(setMovies);
  }, []);

  return (
    <div className="movies-grid">
      {movies.map(movie => (
        <div
          key={movie.id}
          className="movie-card"
          onClick={() => onSelect(movie.id)}
        >
          <h3>{movie.title}</h3>
          <p>{movie.tagline}</p>
          <p>Rating: {(movie.vote_average / 10).toFixed(1)}</p>
        </div>
      ))}
    </div>
  );
}

function MovieDetail({ id, onBack }) {
  const [movie, setMovie] = useState(null);

  useEffect(() => {
    fetch(`/api/movies/${id}`)
      .then(res => res.json())
      .then(setMovie);
  }, [id]);

  if (!movie) return <p>Loading movie details...</p>;

  const localizedDate = movie.release_date
    ? new Date(movie.release_date).toLocaleDateString()
    : 'N/A';

  return (
    <div>
      <button onClick={onBack}>← Back to list</button>
      <h1>{movie.title}</h1>
      <p><strong>Tagline:</strong> {movie.tagline || 'N/A'}</p>
      <p><strong>Rating:</strong> {(movie.vote_average / 10).toFixed(1)}</p>
      <p><strong>Release Date:</strong> {localizedDate}</p>
      <p><strong>Runtime:</strong> {movie.runtime ? movie.runtime + ' minutes' : 'N/A'}</p>
      {/* Display all other fields */}
      <pre>{JSON.stringify(movie, null, 2)}</pre>
    </div>
  );
}

export default function App() {
  const [selectedMovieId, setSelectedMovieId] = useState(null);

  return (
    <div style={{ padding: 20 }}>
      {selectedMovieId ? (
        <MovieDetail id={selectedMovieId} onBack={() => setSelectedMovieId(null)} />
      ) : (
        <MoviesList onSelect={setSelectedMovieId} />
      )}
    </div>
  );
}
