const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3001;

const moviesPath = path.join(__dirname, 'movies_metadata.json');
const rawData = fs.readFileSync(moviesPath, 'utf-8');
const movies = JSON.parse(rawData);

function findMovieById(id) {
  return movies.find(m => String(m.id) === String(id));
}

app.get('/api/movies', (req, res) => {
  const list = movies.map(m => ({
    id: m.id,
    title: m.title,
    tagline: m.tagline,
    vote_average: m.vote_average
  }));
  res.json(list);
});

app.get('/api/movies/:id', (req, res) => {
  const movie = findMovieById(req.params.id);
  if (!movie) return res.status(404).json({ error: 'Movie not found' });
  res.json(movie);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
